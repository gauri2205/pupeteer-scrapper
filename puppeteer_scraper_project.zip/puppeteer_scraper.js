
const puppeteer = require('puppeteer');
const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

app.post('/scrape', async (req, res) => {
  const { platform, username } = req.body;

  if (!platform || !username) {
    return res.status(400).json({ error: 'Missing platform or username' });
  }

  try {
    const browser = await puppeteer.launch({ headless: true, args: ['--no-sandbox'] });
    const page = await browser.newPage();

    let profileUrl = '';
    let postSelector = '';
    switch (platform.toLowerCase()) {
      case 'instagram':
        profileUrl = `https://www.instagram.com/${username}/`;
        postSelector = 'article a'; // first post anchor
        break;
      case 'youtube':
        profileUrl = `https://www.youtube.com/@${username}/videos`;
        postSelector = 'ytd-grid-video-renderer a#video-title';
        break;
      case 'linkedin':
        profileUrl = `https://www.linkedin.com/in/${username}/recent-activity/`;
        postSelector = 'a.app-aware-link'; // generic post link selector
        break;
      default:
        await browser.close();
        return res.status(400).json({ error: 'Unsupported platform' });
    }

    await page.goto(profileUrl, { waitUntil: 'networkidle2' });

    const postURL = await page.evaluate((sel) => {
      const link = document.querySelector(sel);
      return link ? link.href : null;
    }, postSelector);

    await browser.close();

    if (postURL) {
      res.json({ postURL });
    } else {
      res.status(404).json({ error: 'No post found' });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Scraping failed' });
  }
});

app.listen(PORT, () => {
  console.log(`Scraper server running on port ${PORT}`);
});
